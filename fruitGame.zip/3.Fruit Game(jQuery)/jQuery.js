var playing = false;
var score;
var trialsLeft;
var fruits = ['apple','banana','cherries','grapes','mango','orange','peach','pear','watermelon'];
var action;
var step;
$(function(){
	//click on start reset button
	$("#startreset").click(function(){
		//are we playing
		//yes
		if(playing == true){
			location.reload();
		}
		//no
		else{
			//are we playing 
			//no
			playing = true; //game initiated
			
			//set score to 0
			score = 0;
			$("#scoreValue").html(score);

			//show trial left
			$("#trialsLeft").show();
			trialsLeft = 3;
			addHearts();

			//hide the game over div
			$("#gameOver").hide();

			//change button text to reset game
			$("#startreset").html("Reset Game");

			//start sending fruits
			startAction();
		}
	});

 	$("#fruit1").mouseover(function(){
 		score++;
 		//update score
 		$("#scorevalue").html(score);

 		//play sound
 		//two ways of accessing the sound
 		// document.getElementById("slicesound").play();//using basic javascript
 		$("#slicesound")[0].play();//using jQuery

 		//stop the fruit
 		clearInterval(action);

 		//slicing the fruit
 		$("#fruit1").hide("explode","500");
 		
 		//wait for the animation to complete and then send new fruits
 		setTimeout(startAction,500);
 	});

	
	//funciton declarations

	//add hearts
	function addHearts(){
		$("#trialsLeft").empty();//empty the box before updating the new value
		for(i = 0 ; i < trialsLeft; i++){
			$("#trialsLeft").append('<img src="images/heart.png" class = "life">');
		}
	}

	// start sending fruits
	function startAction(){
		// $("#fruitsContainer").append('<img src="images/apple.png" class = "fruits">');
		$("#fruit1").show();
		chooseFruit();// generating random fruits
		$("#fruit1").css({"left" : Math.round(Math.random()*550), "top" : -50});//random position

		//speed of the fruits
		step = 1 + Math.round(Math.random()*5);
		action = setInterval(function(){
			$("#fruit1").css("top",$("#fruit1").position().top+step);

			//checking if fruit is too low
			if($("#fruit1").position().top > $("#fruitsContainer").height()){
				//if trial left
				if(trialsLeft > 1){
					$("#fruit1").show();
					chooseFruit();// generating random fruits
					$("#fruit1").css({"left" : Math.round(Math.random()*550), "top" : -50});//random position

					//speed of the fruits
					step = 1 + Math.round(Math.random()*5);

					//reduce trial left by 1
					trialsLeft--;

					//call updated trial left
					addHearts();
				}
				else{//if no trials left
					playing = false; //as we will not be able to play anymore

					//set reset button to start again
					$("#startreset").html("Start Game");

					//show Game over div
					$("#gameOver").show();
					$("#gameOver").html("<p>Game Over!</p><p>Your score is "+ score +"</P>")
					$("#trialsLeft").hide();
					stopAction();
				}
			}
		},10);
	}

	//generating random fruits
	function chooseFruit(){
		$("#fruit1").attr("src" , "images/"+fruits[Math.round(Math.random()*8)]+".png");
	}

	//stop dropping fruits
	function stopAction(){
		
		$("#fruit1").hide();
	}
});


//Steps to follow:- 
//click on start reset button
	//are we playing
		//yes
			//reload page
		//no
			//show trial left
			//change button text to reset game
			//1. create random fruits
			//define a random step
			//2. move fruit down step every 30 seconds
				//is fruit too low?
					//no -> repeat number 2
					//yes -> any trials left?
						//yes -> show number 1
						//no -> show game over, button text: start game


//slice fruit
	//play sound
	//explode fruit